
server.crt: public-key certificate, signed by CA.
            
server.key: private key
            The password used for protecting the private key is your ALX Student ID

CA.crt: CA's public-key certificate
